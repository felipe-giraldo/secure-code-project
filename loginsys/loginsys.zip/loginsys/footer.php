<?php
  
  
  if (!defined("_VALID_PHP"))
      die('Direct access to this location is not allowed.');
?>
<!-- Start Footer-->
<footer id="footer" class="clearfix">
  Copyright &copy;<?php echo date('Y').' '.$core->site_name;?><br />
    Secure Coding Project v 0.1
</footer>
<!-- End Footer-->
</div><!-- container /-->
</body></html>