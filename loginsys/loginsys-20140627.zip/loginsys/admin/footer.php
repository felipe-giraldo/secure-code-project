<?php
  
  if (!defined("_VALID_PHP"))
      die('Direct access to this location is not allowed.');
?>
</div>
<div class="top20">&nbsp;</div>
<!-- Start Footer-->
<div class="footer">
  Copyright &copy;<?php echo date('Y').' '.$core->site_name;?><br />
    Secure Coding Project v 0.1
</div>
<!-- End Footer-->
<!-- The Main Menu Js -->
<script type="text/javascript">
var menu = new cbpHorizontalSlideOutMenu(document.getElementById('cbp-hsmenu-wrapper'));
</script>
<!-- The Main Menu Js /-->
</body></html>