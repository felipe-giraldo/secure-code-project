<html>
<body>
	<h1>APACHE TEST!!!</h1>

<?php
// Show all information, defaults to INFO_ALL
phpinfo();
?>

</body>
</html>
